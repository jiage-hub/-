<?php
session_start();
if($_SESSION["code"]==$_GET['s7']){
	$servername = "localhost";
	$username = "wm.com";
	$password = "26dXH87rGwBacZSS";
	$dbname = "wm.com";
	// 创建连接
	$conn = new mysqli($servername, $username, $password, $dbname);
	// 检测连接
	if ($conn->connect_error) {
	    die("连接失败: " . $conn->connect_error);
	} 
			session_start();
			$s0=$_SESSION["username"];
			$s1=$_GET['s1'];
			$s2=$_GET['s2'];
			$s3=$_GET['s3'];
			$s4=$_GET['s4'];
			$s5=$_GET['s5'];
			$s6=$_GET['s6'];
			if($s1==""||$s2==""||$s3==""||$s4==""||$s5==""||$s6==""){
				 echo "1";
				
			}else{
	        $sql = "insert into adderss(username,联系人,性别,手机号,收货地址,门牌号,标签) values('$s0','$s1','$s2','$s3','$s4','$s5','$s6')";
	     
	        if ($conn->query($sql) === TRUE) {
				echo "2";
	        } else {
	        echo "3";
	        }
			
			}

			$conn->close();
}else{
	echo "4";
}
?>
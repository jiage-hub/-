<?php
session_start();
$_SESSION["username"]=null;
echo "<script>window.alert('已退出账号');window.location='../index.php';</script>";
?>
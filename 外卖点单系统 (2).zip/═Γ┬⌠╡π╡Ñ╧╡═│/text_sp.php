	
<?php require_once('Connections/wm.com.php');?>

<?php
	
	// 检测连接
	if ($conn->connect_error) {
		die("连接失败: " . $conn->connect_error);
	} 
	
	$a=$_GET['a'];
	
	$sql="SELECT * FROM 商品信息 ORDER BY 营业状态 ASC;";//综合排序 SELECT * FROM 商品信息 ORDER BY 星级评价 DESC;
	$sql2="SELECT * FROM 商品信息 ORDER BY 月售 DESC";//销量高
	$sql3="SELECT * FROM 商品信息 ORDER BY 距离 ASC";//距离近
	$sql4="SELECT * FROM 商品信息 ORDER BY 配送时间 ASC";//速度快
	$sql_tmp=$sql;
	if($a==1){
		$sql_tmp=$sql;
	}
	if($a==2){
		$sql_tmp=$sql2;
	}
	if($a==3){
		$sql_tmp=$sql3;
	}
	if($a==4){
		$sql_tmp=$sql4;
	}
	
	
	

	
	$result = $conn->query($sql_tmp);
	if ($result->num_rows > 0) {
	    // 输出数据
	    while($row = $result->fetch_assoc()) {
			$s0=$row['商家id'];
			$s1=$row['商店头像'];
			$s2=$row['商店名称'];
			$s3=$row['月售'];
			$s4=$row['起送价格'];
			$s5=$row['配送价格'];
			$s6=$row['距离'];
			$s7=$row['配送时间'];
			$s8=$row['主营商品'];
			$s9=$row['ico'];
			$s10=$row['星级图标'];
			$s11=$row['星级评价'];
			$s12=$row['优质商家'];
			$s13=$row['标签'];
			$s14=$row['营业状态'];
			
			
			$label_tmp="";
			$label="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input style='
						border: solid 1px #4caf50;
						color: #4caf50;
						' type='button' value='$s13'  id='but1' />
						</td>";
			$label2="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<input style='
						border: solid 1px #ff5959;
						color: #ff5959;
						' type='button' value='$s13'  id='but1' />
						</td>";			
						
						
			
			if($s13=="支持自取"){
				$label_tmp=$label;
			}else{
				
				if($s13==""){
					
				}else{
					$label_tmp=$label2;
				}
			}
			$click_tmp="进入商家(this.id,$s5)";
			$s14_tmp="";
			$class_sp="";
			if($s14=="休息中"){
					$s14_tmp="<span>休息中</span>";
					$click_tmp="休息中()";
					$class_sp="style='opacity: 0.5;background-color: #FFFFFF;'";
			}
			
			echo "<div class='sp' onclick='$click_tmp'  id='$s0' value='$s0'  $class_sp>
				<div $class_sp>
				<table>
				<tr>
				<td style='width: 260px;'>
				<img id='spimg' src='$s1'/>	$s14_tmp
				<B><p>$s2</p></B>
				<p style='font-size: 11px;color: #332a2a;'>&nbsp;&nbsp; $s10
				 $s11 &nbsp;&nbsp; 月售:$s3 &nbsp;&nbsp;&nbsp; &nbsp;</p>
				<p style='font-size: 11px;color: #332a2a;'>&nbsp; &nbsp;起送￥ $s4 配送￥ $s5 </p>
				<p style='font-size: 11px;color: #332a2a;'>&nbsp; &nbsp;<img src='$s9'style='width: 16px; height: 16px;'  />$s8</p>
				$label_tmp
				
				<td style='font-size: 12px; color: #545454;width: 160px;'>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				$s6 Km | <a style='font-size: 14px; color: #000000;'> $s7 分钟</a><br>
				<img src='$s12' style='width: 25px; height: 18px;border: none;' />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a
				style='font-size: 12px; color: #ff8100;'
				>快车专送</a>
				</td>
				
				</tr>
				</table>
				</div>
				
				</div>		
				
				<br>
				<hr style='border: none; height: 1.1px;width: 414px; background-color: #F0F0F0;' />
				";
	      
	    }
	}else{
		
		echo "连接服务失败";
	}
	

	$conn->close();
?>
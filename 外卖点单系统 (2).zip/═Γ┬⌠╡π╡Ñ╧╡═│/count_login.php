 <html>
     
     
 
  <head>
      <title> login </title>
 <style>
			
		#login{
			
			width: 100%;
			height: 100%;
			position: fixed;
			background-color: black;
			opacity: 0.73;
			z-index: 20;
			top: 0px;
			left: 0px;
			
		}
		#passwd{
			appearance:none;
			-moz-appearance:none;
			-webkit-appearance:none;
			 position: absolute;
			width: 900px;
			height: 150px;
			position: absolute;
			top: 45%;
			left: 4%;
			BACKGROUND-COLOR: #4e4c47c2;
			BORDER-BOTTOM: #4e4c47c2 2px solid;
			border: none;
			font-size: 100px;
			
			z-index: 30;
		}
		#loginbtn{
			
			appearance:none;
			-moz-appearance:none;
			-webkit-appearance:none;
			 position: absolute;
			
			 width: 300px;
			 height: 120px;
			 position: absolute;
			 top: 59%;
			 left: 35%;
			 color: aliceblue;
			 font-size: 70px;
		}
    </style>
    <script>
     
      function logbtn(){
		  var passwds=	document.getElementById('passwd').value;
		  if(passwds=="admin"){
			  
			  document.getElementById('login').style.display='none';
			  
		  }
	  }
    </script>
   </head>
        
    <body>
<div id='login'>
	<form id="form2" name="form2" method="GET" action="count.php">
	<input type="hidden" name="tbname" value="wm_data"/>
	<input type="password" name="pass" id="passwd" placeholder="Pass"/>
	<input style="display: none;" type="submit" value="login" id='loginbtn' onclick="logbtn()" />
	<p style="color: aliceblue; position:absolute;top: 34%;left: 3.2%; font-size:80px">请登陆系统:</p>
	</form>
</div>
</body>
</html>

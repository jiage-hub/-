<?php
	$servername = "localhost";
	$username = "wm.com";
	$password = "26dXH87rGwBacZSS";
	$dbname = "wm.com";
	// 创建连接
	$conn = new mysqli($servername, $username, $password, $dbname);
?>

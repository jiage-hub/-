   <?php 
   	session_start();
	$_SESSION["count_login"]=$_GET["pass"];
   if($_SESSION["count_login"]==admin){
	   
	   
   }else{
	   
	echo "<script>window.alert('账号或密码错误');window.location='count_login.php';</script>";
   }
   ?>
			
				<script>
                
                
                function ref(){
            		 var xml;
            		    
            		    if (window.XMLHttpRequest)
            			{
            				// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
            				xmlhttp=new XMLHttpRequest();
            			}
            			else
            			{
            				// IE6, IE5 浏览器执行代码
            				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            			}
            			xmlhttp.onreadystatechange=function()
            			{
            				if (xmlhttp.readyState==4 && xmlhttp.status==200)
            				{
            				    //window.alert(xmlhttp.responseText);
            					document.getElementById('zt').innerHTML=xmlhttp.responseText;
            				   
            						
            				}
            			}
            			xmlhttp.open("GET","count.php?tbname=wm_data&name",true);
            			xmlhttp.send();
            			
            		
			
                    	}
                	   
                	function start(){
                	    
                	     
                	    setInterval('ref()',1000);
                	    
                	}
                
                </script>

<?php

		$tbname=$_GET["tbname"];
		if($tbname=="外卖"||$tbname=="wm_data"){
		$servername = "localhost";
		$username = "py_text";
		$password = "5Xzde38CLr6DMinZ";
		$dbname = "py_text";
		// 创建连接
		if($_GET["name"]==""){
		    $textcolor='#4b3320';
		}else{
		    
		      $textcolor='#4b3320';
		    
		}
		
		$conn = new mysqli($servername, $username, $password, $dbname);
		// 检测连接
		if ($conn->connect_error) {
			die("连接失败: " . $conn->connect_error);
		} 
		
		
			$sql2="SELECT count(id) t FROM $tbname";
			$result = $conn->query($sql2);
			
			
			if ($result->num_rows > 0) {
			    // 输出数据
			    while($row = $result->fetch_assoc()) {
					
					echo "<br><br><br><br><h1 style='font-size: 70px; color:$textcolor ;'>	&nbsp;数据库总量:".$row["t"]." 条数据</h1>";
			       
			    }
			    
			}
			$start="";
			$sql3="";
			if($_GET["name"]==""){
			$sql3="SELECT * FROM $tbname where id = (SELECT max(id) FROM $tbname)";
			$time_txt="<hr>最新数据的时间: ";
			$start="start()";
		    $textcolor='#4b3320';
		    $bgcolor='#f6f1e4';
			
			}
			else{
			        $names=$_GET["name"];
			        if(strlen($names)>=34){
			            echo "<h1 style='font-size: 100px; color: $textcolor;'>"."想sql注入?  想多了"."</h1>";
			        }else{
			    	$sql3="SELECT * FROM $tbname where INSTR (name,'$names') or INSTR (number,'$names') or INSTR (宿舍,'$names')
					 or INSTR (CONCAT(name,宿舍),'$names') or INSTR (CONCAT(宿舍,name),'$names') or INSTR (CONCAT(number,name),'$names')
					 or INSTR (CONCAT(name,number),'$names')  or INSTR (CONCAT(name,time),'$names')  or INSTR (CONCAT(宿舍,name,time),'$names') 
					 order by time desc LIMIT 0,1000";
			    	$time_txt="<br><hr>购买时间: ";
			    	$textcolor='#4b3320';
		            $bgcolor='#f6f1e4';
		            $heid_ss="none";
			        }
			}
		
			$i=0;
			$result2 = $conn->query($sql3);
			if ($result2->num_rows > 0) {
			    // 输出数据
				$len_resl=$result2->num_rows;
				if($len_resl==1){
					
				}else{
					if($len_resl==1000)
					echo "<h1  style='font-size: 50px;'>搜索: \" $names \" &nbsp;&nbsp;&nbsp;&nbsp;搜索到 ≥$len_resl 条数据 </h1>";
					else
					echo "<h1  style='font-size: 50px;'>搜索: \" $names \" &nbsp;&nbsp;&nbsp;&nbsp;搜索到 $len_resl 条数据 </h1>";
				}
				
			    while($row2 = $result2->fetch_assoc()) {
			        
			      
					$i++;
					  
					echo "
					
					<div style='font-size: 53px; color: $textcolor;>
					
					
						
						<p id='a'  style='font-size: 10px; color: $textcolor;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						
						
						
						
						第 $i 条数据</p>
					$time_txt"
					.$row2["time"]
					
					."<br>
					姓名: ".$row2["name"]
					."<br>
					手机号码: ".$row2["number"]
					."<br>
					宿舍: ".$row2["宿舍"]
					."<br>
					购买物品: ".$row2["text"]
					."<br>
					地址: ".$row2["地址"]
					."<br>
					Urlid: ".$row2["url_id"].
					
					"</div><hr><br>
					";
			      
			    }
			    
		
			
			$conn->close();
			
		}else{
		     echo "<h1>没有该数据</h1>";
		}
		
		}else{
		    
		    echo "<h1 style='font-size: 100px; color: #4b3320;'>"."想sql注入？  想多了"."</h1>";
		}
		

	

?>
<html>
<head>
    
    <title><?php echo $tbname; ?> </title>
    <style>
        	body{
                		width: 1200px;
                		height: auto;
                	    color: #4b3320;
                		top: 3%;
                		background-color: <?php echo $bgcolor;?>;
                	}
        
            #ss{
                width: 100%;
                height: 57%;
                background-color: #f6f1e4;
                position:fixed;
                top: 0%;
                left: 0px;
            }
            #in_ss{
                position: absolute;
                top: 60%;
                left: 0%;
                width: 67.8%;
                height: 150px;
                font-size: 100px;
				border: none;
               	appearance:none;
        		-moz-appearance:none;
        		-webkit-appearance:none;
        		 BACKGROUND-COLOR: #f6f1e4;
                BORDER-BOTTOM: #f6f1e4 2px solid;
                color: #4b3320;
        	
               
                
            }
            #bnt{
                	appearance:none;
        		-moz-appearance:none;
        		-webkit-appearance:none;
                 position: absolute;
                top: 60%;
                left: 68%;
                width: 30%;
                height: 150px;
                font-size: 90px;
                color: #4b3320;
                background-color: #f6f1e4;
                border: none;
            }
            p{
               	appearance:none;
        		-moz-appearance:none;
        		-webkit-appearance:none;
                 position: absolute;
                top: 6%;
                left: 21%;
                width: 900px;
                height: 200px;
                font-size: 90px;
                color: #4b3320;
            } 
            #hr2{
                
                	appearance:none;
        		-moz-appearance:none;
        		-webkit-appearance:none;
                 position: absolute;
                top: 24%;
                left: 0%;
				height: 2px;
				background-color: darkslategrey;
				border: none;
                width: 100%;
                font-size: 90px;
                color: #4b3320;
            }
                
            #a{
                position: absolute;
                left: 60%;
            }
            a{
                text-decoration: none;
                color: #c89833;
            }
            hr{
                color: #4b3320;
				width: 1200px;
            }
            #ss_hr{
                  width: 100%;
               
                color: #f6f1e4;
                position:absolute;
                top: 73.6%;
                left: 0px;
                
            }
           #ss_hr2{
                  width: 100%;
               
                color: #f6f1e4;
                position:absolute;
                top: 59.3%;
                left: 0px;
                
            }
            #zt{
				
				 width: 1200px;
			}
			

    </style>

</head>
<body onload='<?php echo $start; ?>'>


<div id='zt'></div>
<div id='ss' style="display:<?php echo $heid_ss;?>;">
    <form action="#" id='form1'>
    <p>信息筛查系统</p><hr id='hr2' >
    <input type="hidden" name="tbname" value="wm_data" / >
	<input type="hidden" value="<?php 	session_start(); echo $_SESSION["count_login"];?>" name="pass" />
	<p style="font-size: 40px; position: absolute;top: 70.4%; left: 2.3%;">(名字) /(手机号) / (宿舍区)<br>(名字+手机号) /( 名字 + 宿舍)<br>
	(宿舍+名字+时间） 两者可互换</p>
    <input type="text" value="" id='in_ss' name="name" placeholder="关键词....." />
    <input type="submit" value="搜 索" id='bnt' />
    <hr id='ss_hr'><hr id='ss_hr2'>
    </form>
    
</div>



</body>

</html>

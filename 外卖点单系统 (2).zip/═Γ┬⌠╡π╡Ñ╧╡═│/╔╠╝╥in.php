<?php require_once('Connections/wm.com.php');?>

<?php
	
	// 检测连接
	if ($conn->connect_error) {
		die("连接失败: " . $conn->connect_error);
	}
	$row=null;
	 $id=$_GET["id"];
	 $jiage=$_GET["jiage"];
	 $sql="SELECT * FROM 商品信息 where 商家id=".$id;
	 $sql2="SELECT * FROM 商品详细信息 WHERE 商家id='$id' GROUP BY 商品种类";
	 $sql3="SELECT * FROM 商品详细信息 WHERE 商家id='$id' ";
	 $result = $conn->query($sql);
	 $result2 = $conn->query($sql2);
	 $result3 = $conn->query($sql3);
	 if ($result->num_rows > 0) {
	     // 输出数据
	    $row = $result->fetch_assoc();
	 }
	
	?>


<html>
	<head>
		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
		<meta charset="utf-8">
		<title><?php echo $row["商店名称"];?></title>
		<style>

				

	html, body {
	    max-width: 100%;
	
	    overflow-x: hidden;
		background-color: #464646;
		margin:0;
		padding:0;
	
	}
	
			#商家in{
				
				height: auto;
				width: 36px;
				z-index: 300;
				position: absolute;
				display: block;
				top: 3px;
				left: 11px;
				position: fixed;
				
			}
			#exit{
				
				width: 35px;
				height: 35px;
			}
			#tito{
				width: 414px;
				height: 80px;
				left: 0px;
				background-color: #464646;
				position: absolute;
				top: 5.8%;
				z-index: 2;
			}
			#菜单栏{
				width: 414px;
				height: 46px;
				background-color: #ffffff;
				position: absolute;
				top: 17.8%;
				left: 0px;
				z-index: 2;
			}
			#菜单栏 a{
				position: absolute;
				top: 18px;
				z-index: 2;
				color: #615858;
			}
			#左侧栏{
				width: 95px;
				height: 100%;
				position:fixed;
				top: 23%;
				left: 0px;
				background-color: #efeeee;
				z-index: 1;
			}
			#内容栏{
				position: absolute;
				left: 95px;
				top: 24%;
				background-color: #ffffff;
				width: 319px;
				height: auto%;
				z-index: 1;
			}
			#评价in{
				position: fixed;
				top: 24%;
				width: 414px;
				height: 100%;
				background-color: #FFFFFF;
				display: none;
				z-index: 40;
				left: 0;
			}
			#商家in2{
				position: fixed;
				top: 24%;
				width: 414px;
				height: 100%;
				background-color: #FFFFFF;
				display: none;
				z-index: 40;
				left: 0;
			}
			#tito img{
				position: fixed;
				top: 50px;
				left: 13px;
				width: 70px;
				height: 60px;
				border-radius: 5px 5px 5px 5px ;
				vertical-align: middle;
			}
			#tito #起送价格{
				position: absolute;
				left: 90px;
				top: 8px;
				color: #FFFFFF;
				font-size: 16px;
				
			}
			#tito #距离{
				position: absolute;
				left: 200px;
				top: 8px;
				color: #FFFFFF;
				font-size: 15px;
			}
			#tito #快车专送{
				position: absolute;
				left: 240px;
				top: 8px;
				color: #FFFFFF;
				font-size: 15px;
				background-color: #ff9800;
				width: 138px;
				height: 19px;
				font-size: 14px;
				border-radius: 5px 5px 5px 5px ;
			}
			#tito #标签{
				position: absolute;
				left: 90px;
				top: 55px;
				color: #FFFFFF;
				font-size: 15px;
				background-color: #8bc34a;
				width: 72px;
				height: 19px;
				font-size: 14px;
				border-radius: 5px 5px 5px 5px ;
			}
			#tito #公告{
				position: absolute;
				left: 90px;
				top: 15px;
				color: #FFFFFF;
				font-size: 15px;
			}
			#商品种类{
				
				
			}
			#购买{
				width: 414px;
				height: 60px;
				background-color: #ff5722;
				position: fixed;
				top: 93%;
				left: 0;
				z-index: 50;
			}
			#购买img,#购买img img{
				width: 67px;
				height: 67px;
				border-radius: 50px 50px 50px 50px ;
				position: fixed;
				top: 89%;
				left: 29px;
				z-index: 200;
				
			}
			#购买btn{
				width: 45px;
				height: 20px;
				border-radius: 50px 50px 50px 50px ;
				background-color: #ff2222e8;
				position: fixed;
				top: 88%;
				left: 45px;
				z-index: 200;
				color: #FFFFFF;
				font-size: 14px;
				text-indent: 0.3em;
			}
			#金额{
				
				position: absolute;
				top: 0px;
				font-size: 18px;
				color: #FFFFFF;
				left: 90px;
			}
			#配送价格{
				position: absolute;
				top: 23px;
				font-size: 13px;
				color: #FFFFFF;
				left: 148px;
				
			}
			#去结算{
				position: absolute;
				height: 56px;
				top: 0px;
				width: 149px;
				font-size: 23px;
				color: #FFFFFF;
				left: 264px;
				background-color: #ff9800;
				appearance:none;
				-moz-appearance:none;
				-webkit-appearance:none;
				border: none;
				
			}
		</style>
		<script>
			
			function load(){
				
				点菜();
				
			}
			function exit(){
			
			top.location="index.php";
		
			}
			function  点菜(){
				document.getElementById('点菜').style.color='#ff8d00';
				document.getElementById('商家').style.color='#615858';
				document.getElementById('评价').style.color='#615858';
				document.getElementById('商家in2').style.display='none';
				document.getElementById('评价in').style.display='none';
				document.getElementById('tito').style.position='absolute';
				document.getElementById('菜单栏').style.position='absolute';
				document.getElementById('内容栏').style.display='block';
				document.getElementById('购买_x').style.display='block';
			}
			function 评价(){
				document.getElementById('评价').style.color='#ff8d00';
				document.getElementById('商家').style.color='#615858';
				document.getElementById('点菜').style.color='#615858';
				document.getElementById('商家in2').style.display='none';
				document.getElementById('评价in').style.display='block';
				document.getElementById('tito').style.position='fixed';
				document.getElementById('菜单栏').style.position='fixed';
				document.getElementById('内容栏').style.display='none';
				document.getElementById('购买_x').style.display='none';
			}
			function 商家(){
				document.getElementById('商家').style.color='#ff8d00';
				document.getElementById('点菜').style.color='#615858';
				document.getElementById('评价').style.color='#615858';
				document.getElementById('商家in2').style.display='block';
				document.getElementById('评价in').style.display='none';
				document.getElementById('tito').style.position='fixed';
				document.getElementById('菜单栏').style.position='fixed';
				document.getElementById('内容栏').style.display='none';
				document.getElementById('购买_x').style.display='none';
			}
			var myArray=new Array()
			var i=1;
			function 商品种类(a,b){
				myArray[i]=a.id;
				i++;
					
						document.getElementById(a.id).style.backgroundColor='#FFFFFF';
						document.querySelector("#河粉");
						
						window.location.href="#"+b;
						document.getElementById(myArray[i-2]).style.backgroundColor='#efeeee';
						
					
				
				
				
			}
			var 加入i=0;
			var 单价i=0;
			function 加入(单价,jiage){
				加入i++;
				单价i+=单价;
				var 金额=单价i.toFixed(2);
				
				document.getElementById('购买btn').innerText=加入i;
				document.getElementById('购买btn').style.display='block';
				document.getElementById('购买_x').style.display='block';
				document.getElementById('金额').innerText="￥"+ 金额;
				document.getElementById('配送价格').innerText="另需配送费 ￥"+jiage;
			}
		</script>
	</head>
	<body onload="load()">
		
		<div id="商家in">
			<img id="exit" src="ico/返回2.png" onclick="exit()" /><br />
		</div>
			<div id="tito">
				<img src="<?php echo $row['商店头像'];?>" />
				<a id="起送价格"><?php echo "￥".$row['起送价格']."起送  &nbsp;&nbsp;|";?></a><a id="距离"><?php echo $row['距离']."Km";?></a>
				<div id="快车专送">&nbsp;快车专送-约 <?php echo $row['配送时间']."分钟";?></div>
				<p id="公告">公告: <?php echo $row['公告'];?> </p>
				<div id="标签">&nbsp; <?php echo $row['标签'];?></div>
			</div>
			<div id="菜单栏">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a id="点菜" onclick="点菜()"><B>点菜</B></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a id="评价" onclick="评价()"><B>评价</B></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a id="商家" onclick="商家()"><B>商家</B></a>
				
			</div>
			
			<div id="左侧栏">
				
				<?php 
				if ($result2->num_rows > 0) {
				    // 输出数据
				  while($row2 = $result2->fetch_assoc()){
					$商品种类=$row2['商品种类'];
					$商品种类标识号=$row2['商品种类标识号'];
				
				echo "<div  id='$商品种类' style='position: absolute;
				left: 0px;
				width: 97px;
				height: 20px;
				padding:20px;
				text-align:10px;
				' onclick='商品种类(this,$商品种类标识号)'>"."".$row2['商品种类']."</div><br><br><br>"
				
				;
				}}
				?>
				
				
			</div>
			<div id="内容栏">
				
				<?php 
				if ($result3->num_rows > 0) {
				    // 输出数据
				  while($row3 = $result3->fetch_assoc()){
					  $图片=$row3['图片'];
					  $商品名称=$row3['商品名称'];
					  $商品种类=$row3['商品种类'];
					  $商品单个销量=$row3['商品单个销量'];
					  $单价=$row3['单价'];
					  $标签=$row3['标签'];
					  $商品种类标识号=$row3['商品种类标识号'];
					   
					  echo "<br><div><img src='$图片' style='position: absolute;
				border-radius: 3px 3px 3px 3px ;
				width: 85px;
				height: 70px;
				left: 9px;
				vertical-align: middle;
				' />"."<B><a id='$商品种类标识号'
				style='position: absolute;
				left:98px;
				font-size:17px;
				'
				>
				$商品名称
				</a></B>
				<br>
				<a
				style='position: absolute;
				left:100px;
				color: #716b6b;
				font-size:10px;
				'
				>$商品种类</a><br>
				<a
				style='position: absolute;
				left:100px;
				color: #716b6b;
				font-size:10px;
				'
				>销量: $商品单个销量</a>
				<br>
				<a
				style='position: absolute;
				left:100px;
				color: #ff5722;
				font-size:20px;
				'
				>￥ $单价</a>
				<input 
				style='position: absolute;
				left:200px;
				color: #ffffff;
				font-size:14px;
				background-color: #ff9800;
				width: 60px;
				height: 25px;
				appearance:none;
				-moz-appearance:none;
				-webkit-appearance:none;
				border: none;
				border-radius: 10px 10px 10px 10px ;
				'
				type='button' value='加入' onclick='加入($单价,$jiage)' />
				<p style=' font-size:26px;'></p>
				<input
				 style='position: absolute;
				 left:100px;
				 color: #4caf50;
				 font-size:10px;
				 background-color: #ffffff;
				 width: 60px;
				 height: 20px;
				 appearance:none;
				 -moz-appearance:none;
				 -webkit-appearance:none;
				 border:solid 1px #4caf50;
				
				 '
				 type='button' value='$标签' onclick='' />
				</div><br><br><br>";
					  
					  
				}
				}
				
				
				
				?>
				
				<br><br><br><br><br>
				
				<br><br><br><br><br><br><br>
				
			</div>
			
			<br><br><br><br><br><br><br ><br><br><br><br>
			<div id="评价in">评价in</div>
			<div id="商家in2">商家in</div>
			
			<div id="购买_x" style="display: none;">
			<div id="购买"><a id="金额"></a> <a id="配送价格"></a>
			<input id="去结算" type="button" value="去结算" />
			</div>
			<div id="购买img"><img  src="ico/购物车.png" /></div>
			<div id="购买btn" style="display: none;"></div>
			</div>
		
	</body>
</html>

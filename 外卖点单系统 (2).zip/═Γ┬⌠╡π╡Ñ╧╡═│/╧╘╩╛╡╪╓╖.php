<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<style>
			#显示地址_btu{
				width: 400px;
				height: 140px;
				border: none;
						
				/*很关键：将默认的select选择框样式清除*/
				appearance:none;
				-moz-appearance:none;
				-webkit-appearance:none;
				font-size: 15px;
				
			}
			hr{
				background-color: #FF8800;
				border: none;height: 1px;
				opacity: 0.5;

			}
			#sc{		
		border: solid 1px #000;
				
		/*很关键：将默认的select选择框样式清除*/
		appearance:none;
		-moz-appearance:none;
		-webkit-appearance:none;
		border: none;
		width: 65px;
		background-color: #ff880080;
		height: 24px;
		font-size: 10px;
		color: #000000;
	}
		</style>
		<script>
			function 显示地址(){
				
				var xml;
				   
				   if (window.XMLHttpRequest)
							{
								// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
								xmlhttp=new XMLHttpRequest();
							}
							else
							{
								// IE6, IE5 浏览器执行代码
								xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
							}
							xmlhttp.onreadystatechange=function()
							{
								if (xmlhttp.readyState==4 && xmlhttp.status==200)
								{
									document.getElementById("显示地址_btu").innerHTML=xmlhttp.responseText;
								
								}
							}
							xmlhttp.open("GET","show_adderss.php",true);
							xmlhttp.send();
							
			}
			

				
			function del_adderss(){
				
			var xml;
			var s1=document.getElementById('s1').value;	  
			var s2=document.getElementById('s2').value;	
			var s3=document.getElementById('s3').value;	
			var s4=document.getElementById('s4').value;	
			
			 
				   if (window.XMLHttpRequest)
							{
								// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
								xmlhttp=new XMLHttpRequest();
							}
							else
							{
								// IE6, IE5 浏览器执行代码
								xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
							}
							xmlhttp.onreadystatechange=function()
							{
								if (xmlhttp.readyState==4 && xmlhttp.status==200)
								{
									
									window.alert(xmlhttp.responseText);
									显示地址();
								}
							}
							xmlhttp.open("GET","del_adderss.php?ss1=123&s1="+s1+"&s2="+s2+"&s3="+s3+"&s4="+s4,true);
							xmlhttp.send();
							
			}
		</script>
	</head>
	<body onload="显示地址()">
		<div id="显示地址_btu"></div>
		
		
	</body>
</html>

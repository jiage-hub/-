<?php require_once('Connections/wm.com.php');?>
<?php
// 检测连接
	if ($conn->connect_error) {
		die("连接失败: " . $conn->connect_error);
	} 
	
	
	
	
	session_start();
	$user=$_GET['user'];
	$pass=$_GET['pass'];
	$code=$_GET['code'];
	if(strlen($user)>20||strlen($pass)>20||strlen($code)>20){
		echo "字符长度不合法";
	}else{
		if($code== $_SESSION["code"]){
			if($user==""||$pass==""){
				
				echo "<script>window.alert('请输入账号密码！！');</script>";
				
			}else{
				$sql2="insert into admin_user(username,password) values('$user','$pass')";
				if($conn->query($sql2)){
					echo "注册成功";
					
				}else{
					echo "已经存在此账号";
					
				}
			
				
				$conn->close();
				
			}
			
		}else{
			
			echo "验证码错误";
		}
	}
?>
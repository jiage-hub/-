<?php require_once('Connections/wm.com.php');?>
<?php

	// 检测连接
	if ($conn->connect_error) {
		die("连接数据库失败: " . $conn->connect_error);
	} 
	
	session_start();  
	$s0=$_SESSION["username"];
	$s1=$_GET['s1'];
	$s2=$_GET['s2'];
	$s3=$_GET['s3'];
	$s4=$_GET['s4'];
	$ss1=$_GET['ss1'];
	$sql2="DELETE FROM adderss WHERE username='$s0' AND 收货地址='$s1' AND 门牌号='$s2'  AND 联系人='$s3' AND 手机号='$s4'";
	if($conn->query($sql2)){
		echo "删除成功";
	}
	
	
	//echo "<script>window.alert('删除成功');window.location='index.php';</script>";
?>
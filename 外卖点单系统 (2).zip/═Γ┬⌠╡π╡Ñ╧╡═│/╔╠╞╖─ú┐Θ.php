<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
		
		
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/图片切换.css" />
		<script type="text/javascript" src="js/图片切换.js"></script>
		<style>
	body{
		background-color: #ffffff;
	}
	#展示图片模块{
		width: 360px;
		height: 125px;
		background-color: #FFFFFF;

		top: 1.5%;
		border-radius:20% 20% 20% 20%;
	}
	#食品分类模块{
		width: 360px;
		height: 169px;
		background-color: #FFFFFF;
		
		z-index: 90;
		top: 19%;
		border-radius: 100px 200px 200px 100px;
	}
	#食品分类模块 img{
		width: 70px;
		height: 70px;
		border-radius: 200px 200px 200px 200px;
	}
	#商家模块{
		width: 360px;
		height: 100%;
		background-color: #ffffff;
		
		top: 42.7%;
	}
	#aec a{
		font-size: 13px;
		
	}

	
	.sp{
		background-color: #FFFFFF;
		width: 360px;
		height: 70px;
		margin-bottom: 5px;
		position: relative;	
		padding: 12px;
		padding-left: 40px;
		
	}
	.sp p{
		text-indent: 2em;
	}
	.sp span{
		top: 67px;
		left: 3px;
		background-color: #7d7777;
		position: absolute;
		z-index: 10;
		width: 68px;
		opacity: 0.6;
		color: #FFFFFF;
		border-radius: 0px 0px 10px 10px;
		text-indent: 10px;
		font-size: 14px;
		height: 18px;
	}
	#spimg{
	height: 70px;
	width: 70px;
	vertical-align: middle;
	position: absolute;
	margin-top: 0px;
	left: 0px;
	border-radius: 15px 15px 15px 15px ;
	z-index: 1;
	}
	#but1{
		border: solid 1px #4caf50;
				
		/*很关键：将默认的select选择框样式清除*/
		appearance:none;
		-moz-appearance:none;
		-webkit-appearance:none;
		font-size:9px ;
		bottom: 1px;
		width: 49px;
		background-color: #FFFFFF;
		height: 15px;
		color: #4caf50;
		border-radius: 2px 2px 2px 2px ;
		
	}
	#筛选{
		display: none;
		background-color: #FFFFFF;
		height: 120px;
		width: 50px;
		position: absolute;
		top: 61%;
		left: 70%;
		z-index: 30;
		border-radius: 5px 5px 5px 5px;
		
		
	}


	</style>
		
	<script>
	function text_sp(a){
		
		var xml;
		   
		   if (window.XMLHttpRequest)
					{
						// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
						xmlhttp=new XMLHttpRequest();
					}
					else
					{
						// IE6, IE5 浏览器执行代码
						xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.onreadystatechange=function()
					{	
						if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
							document.getElementById("text_sp").innerHTML=xmlhttp.responseText;
							
						}
					}
					xmlhttp.open("GET","text_sp.php?a="+a,true);
					xmlhttp.send();
					
	}
	
	function open_http(a){
		
		var xml;
		   
		   if (window.XMLHttpRequest)
					{
						// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
						xmlhttp=new XMLHttpRequest();
					}
					else
					{
						// IE6, IE5 浏览器执行代码
						xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.onreadystatechange=function()
					{	
						if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
							//document.getElementById("text_sp").innerHTML=xmlhttp.responseText;
							
						}
					}
					xmlhttp.open("GET",a,true);
					xmlhttp.send();
					
	}
	
			
	function 进入商家(obj,s5){
		
		var url="/商家in.php?id=" + obj+"&jiage="+ s5 +"&name=";
		  top.location=url;
		//window.open(url);
		
	}
	function 休息中(){
		window.alert("店铺已经打烊咯，明天再来吧");
	}
	function load(){
		
		text_sp(1);
		图片切换();
	}	
	function 筛选a(){
		
		if(document.getElementById('筛选').style.display=='block'){
		document.getElementById('筛选').style.display='none';
		document.getElementById('aec_img').src='ico/arrow2.png';
		document.getElementById('筛选a').style.color='#000000';
		
		}
		else{

		document.getElementById('筛选').style.display='block';
		document.getElementById('aec_img').src='ico/arrow.png';
		document.getElementById('筛选a').style.color='#ff8800';
		}
		
	}
	
	</script>
	</head>
	<body leftmargin="0" onload="load()">

		
		<div id="展示图片模块">
			<div class="box">
				<div class="box-1">
					<ul>
						<li>
							<img src="img/展示图片模块/1.jpg" alt="这里是第一场图片"></img>
							<h2>1</h2>
						</li>
						<li>
							<img src="img/展示图片模块/2.jpg" alt="这里是第二张图片"></img>
							<h2>2</h2>
						</li>
						<li>
							<img src="img/展示图片模块/3.jpg" alt="这里是第三张图片"></img>
							<h2>3</h2>
						</li>
						<li>
							<img src="img/展示图片模块/4.jpg" alt="这里是第一场图片"></img>
							<h2>4</h2>
						</li>
						<li>
							<img src="img/展示图片模块/5.jpg" alt="这里是第一场图片"></img>
							<h2>5</h2>
						</li>
					</ul>
				</div>
				<div class="box-2">
					<ul>
						
					</ul>
				</div>
				<div class="box-3">
					<span class="prev"> < </span>
					<span class="next"> > </span>
				</div>
			</div>
			
		</div>
			<hr style="border: none; height: 1.7px;width: 414px; background-color: #F0F0F0;" />
		<div id="食品分类模块">
		
			<table  id="tab_img" width="390" height="160" border="0" cellspacing="0" cellpadding="0">
				<tr align="center">
				<td><img src="img/食品分类图标/1.gif" onclick="top.location='/商店分类.php?type=1'" />
				<B><p style="z-index: 100; color: #000000;font-size: 11px; top: 28.7%; left: 10.8%;">粉面美食</p>	</B>
				</td>
				
				<td><img src="img/食品分类图标/2.gif" onclick="top.location='/商店分类.php?type=2'" />
				<B><p style="z-index: 100; color: #000000;font-size: 11px; top: 28.7%; left: 42.2%;">炸鸡汉堡</p>	</B>
				</td>
				<td><img src="img/食品分类图标/3.gif" onclick="top.location='/商店分类.php?type=3'"/>
				<B><p style="z-index: 100; color: #000000;font-size: 11px; top: 28.7%; left: 73.8%;">包子粥店</p>		</B>
				</td>
				</tr>
				<tr align="center">
				<td><img src="img/食品分类图标/4.gif" onclick="top.location='/商店分类.php?type=4'"/>
				<B><p style="z-index: 100; color: #000000;font-size: 11px; top: 40.8%; left: 10.8%;">奶茶甜品</p>	</B>
				</td>
				<td><img src="img/食品分类图标/5.gif" onclick="top.location='/商店分类.php?type=5'"/>
				<B><p style="z-index: 100; color: #000000;font-size: 11px; top: 40.8%; left: 42.2%;">小炒快餐</p>	</B>	
				</td>
				<td><img src="img/食品分类图标/6.gif" onclick="top.location='/商店分类.php?type=6'" />
				<B><p style="z-index: 100; color: #000000;font-size: 11px; top: 40.8%; left: 73.8%;">西式简餐</p>		</B>
				</td>
				</tr>
			</table>
			
		</div>





		<div id="商家模块">
			
			<br />
			<br />
			<hr style="border: none; height: 1.7px;width: 414px; background-color: #F0F0F0;" />
			<br />
		<h3>&nbsp;&nbsp;附近商家</h3>
			<div id="aec" >
				&nbsp;&nbsp;<a id="综合排序" onclick="text_sp(1);
				document.getElementById('综合排序').style.color='#FF8800';
				
				document.getElementById('销量高').style.color='#000000';
				document.getElementById('速度快').style.color='#000000';
				document.getElementById('距离近').style.color='#000000';
				">综合排序</a>
				<img style="width: 10px; height: 10px;" src="ico/arrow3.png"/>
				&nbsp;&nbsp;&nbsp;
				<a id="销量高" onclick="text_sp(2);
				document.getElementById('销量高').style.color='#FF8800';
				
				document.getElementById('速度快').style.color='#000000';
				document.getElementById('距离近').style.color='#000000';
				document.getElementById('综合排序').style.color='#000000';
				
				">销量高</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a id="速度快" onclick="text_sp(3);
				document.getElementById('速度快').style.color='#FF8800';
				
				document.getElementById('距离近').style.color='#000000';
				document.getElementById('销量高').style.color='#000000';
				document.getElementById('综合排序').style.color='#000000';
				
				
				
				">速度快</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a id="距离近" onclick="text_sp(4);
				document.getElementById('距离近').style.color='#FF8800';
				
				document.getElementById('速度快').style.color='#000000';
				document.getElementById('销量高').style.color='#000000';
				document.getElementById('综合排序').style.color='#000000';
				
				">距离近</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<a id="筛选a" onclick="筛选a()">筛选&nbsp;&nbsp;<img id="aec_img"  src="ico/arrow2.png"/>
				<div id="筛选">
					<br />
					<a onclick="text_sp(2);
					document.getElementById('销量高').style.color='#FF8800';
					
					document.getElementById('速度快').style.color='#000000';
					document.getElementById('距离近').style.color='#000000';
					document.getElementById('综合排序').style.color='#000000';
					">销量高</a><br /><br />
					<a onclick="text_sp(3);
					document.getElementById('速度快').style.color='#FF8800';
					
					document.getElementById('距离近').style.color='#000000';
					document.getElementById('销量高').style.color='#000000';
					document.getElementById('综合排序').style.color='#000000';
					
					">速度快</a><br /><br />
					<a onclick="text_sp(4);
					document.getElementById('距离近').style.color='#FF8800';
					
					document.getElementById('速度快').style.color='#000000';
					document.getElementById('销量高').style.color='#000000';
					document.getElementById('综合排序').style.color='#000000';
					">距离近</a>
					
					
				</div>
				
				</a>
			</div>
			
			<p style="font-size: 11px;">&nbsp;</p>

			
			<div id="text_sp">
			
		
			
			</div>
		
			
			
			
			
			
			
			<br /><br /><br /><br />
			<br /><br /><br /><br />
			<br /><br /><br /><br />
			<br /><br /><br /><br />
			
		</div>		
		

		
		
		
		
	</body>
</html>

<?php require_once('Connections/wm.com.php');?>
<?php
	// 检测连接
	if ($conn->connect_error) {
		die("连接失败: " . $conn->connect_error);
	} 
	
	session_start();
	$s0=$_SESSION["username"];
	$sql2="SELECT * FROM adderss WHERE username='$s0'";
	$result = $conn->query($sql2);
	 $i=1;
	if ($result->num_rows > 0) {
	    // 输出数据
	    while($row = $result->fetch_assoc()) {
			$s1=$row["收货地址"];
			$s2=$row["门牌号"];
			$s3=$row["联系人"];
			$s4=$row["手机号"];
	       echo "地址".$i++.":&nbsp;&nbsp;".$row["收货地址"]."&nbsp;&nbsp;".$row["门牌号"]."<br />";
		   echo $row["联系人"]."&nbsp;".$row["性别"]."&nbsp;&nbsp;&nbsp;".$row["手机号"]."&nbsp;&nbsp;&nbsp;".$row["标签"]."&nbsp;&nbsp;&nbsp;
		   
		   <input  name='xc' type='button' value='删 除'  id='sc'  onclick='del_adderss()'/>
		   <input type='hidden' id='s1' value='$s1' />
		   <input type='hidden' id='s2' value='$s2' />
		   <input type='hidden' id='s3' value='$s3' />
		   <input type='hidden' id='s4' value='$s4' />
		   <hr />";
	      
	    }
	}
	

	$conn->close();

?>
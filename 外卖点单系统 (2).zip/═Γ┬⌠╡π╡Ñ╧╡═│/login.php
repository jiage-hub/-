<?php require_once('Connections/wm.com.php');?>
<?php
// 检测连接
	if ($conn->connect_error) {
		die("连接失败: " . $conn->connect_error);
	} 
	
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	if($user==""||$pass==""){
		
		echo "<script>window.alert('请输入账号密码！！');window.location='index.php';</script>";
		
	}else{
		$sql2="SELECT * FROM admin_user WHERE username='$user' and password='$pass'";
		$result = $conn->query($sql2);
		if ($result->num_rows > 0) {
		    // 输出数据
		    while($row = $result->fetch_assoc()) {
				
				session_start();
				$_SESSION["username"]=$row["username"];
				$_SESSION["qb"]=$row["钱包"];
				echo "<script>window.alert('登陆成功');window.location='index.php';</script>";
		      
		    }
		}else{
			echo "<script>window.alert('账号或密码错误');window.location='index.php';</script>";
		}
			
		
		$conn->close();
		
	}
?>
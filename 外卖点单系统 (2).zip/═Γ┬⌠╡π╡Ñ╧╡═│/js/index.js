
	function homeico(){
		document.getElementById('dd').style.display='none';
		document.getElementById('user').style.display='none';
		document.getElementById('bg').style.display='block';
		//---按钮的一些颜色控制
		document.getElementById('home_x').style.backgroundColor='#ff8800';
		document.getElementById('home_f').style.color='#ff8800';
		
		document.getElementById('dd_x').style.backgroundColor='#FFFFFF';
		document.getElementById('dd_f').style.color='#000000';
		document.getElementById('user_ico_x').style.backgroundColor='#FFFFFF';
		document.getElementById('user_f').style.color='#000000';
		document.getElementsByTagName("title")[0].innerText = '快车外卖';
	}
	function ddico(){
		document.getElementById('user').style.display='none';
		document.getElementById('dd').style.display='block';
		document.getElementById('bg').style.display='none';
		//---按钮的一些颜色控制
		document.getElementById('dd_x').style.backgroundColor='#ff8800';
		document.getElementById('dd_f').style.color='#ff8800';
		
		document.getElementById('home_x').style.backgroundColor='#FFFFFF';
		document.getElementById('home_f').style.color='#000000';
		document.getElementById('user_ico_x').style.backgroundColor='#FFFFFF';
		document.getElementById('user_f').style.color='#000000';
		document.getElementsByTagName("title")[0].innerText = '订 单';
	}
	function userico(){
		
		document.getElementById('user').style.display='block';
		document.getElementById('dd').style.display='none';
		document.getElementById('bg').style.display='none';
		//---按钮的一些颜色控制
		document.getElementById('user_ico_x').style.backgroundColor='#ff8800';
		document.getElementById('user_f').style.color='#ff8800';
		
		
		document.getElementById('home_x').style.backgroundColor='#FFFFFF';
		document.getElementById('home_f').style.color='#000000';
		document.getElementById('dd_x').style.backgroundColor='#FFFFFF';
		document.getElementById('dd_f').style.color='#000000';
		document.getElementsByTagName("title")[0].innerText = '我的信息';
	}
	
	function 搜索img(){
		document.getElementById('搜索').style.display='none';
		document.getElementById('select_x').style.display='block';
	}
	
	function select_x(){
		document.getElementById('搜索').style.display='block';
		document.getElementById('select2').autofocus='autofocus';
		document.getElementById('select_x').style.display='none';
	}
	function r1(){
		if(document.getElementById('r1').select){
			document.getElementById('r1').style.backgroundColor='#ff8800';
			document.getElementById('r2').style.backgroundColor='antiquewhite';
		
		}
	}
	function r2(){
		if(document.getElementById('r2').select){
			document.getElementById('r2').style.backgroundColor='#ff8800';
			document.getElementById('r1').style.backgroundColor='antiquewhite';
		}
	}
	function dizhifanghui(){
		document.getElementById('我的地址in').style.display='none';
	}
	function 消息in(){
		document.getElementById('消息in').style.display='none';
	}
	function 消息(){
		if(document.getElementById('seesion_user').value!=1){
			
		document.getElementById('消息in').style.display='block';
		}else{
			window.alert("请登陆!");
		}
		
		
	}
	function 优惠卷in(){
		document.getElementById('优惠卷in').style.display='none';
	}
	function 优惠卷(){
		
		if(document.getElementById('seesion_user').value!=1){
			
		document.getElementById('优惠卷in').style.display='block';
		}else{
			window.alert("请登陆!");
		}
		
		
	}
	function 关于我们in(){
		document.getElementById('关于我们in').style.display='none';
	}
	function 关于我们(){
		document.getElementById('关于我们in').style.display='block';
	}
	function 声明和规则in(){
		document.getElementById('声明和规则in').style.display='none';
	}
	function 声明和规则(){
		document.getElementById('声明和规则in').style.display='block';
	}
	function 我的地址(){
		
		
		
		if(document.getElementById('seesion_user').value!=1){
			
		document.getElementById('我的地址in').style.display='block';
		document.getElementById('showadderss_datas').src = "显示地址.php";
		}else{
			window.alert("请登陆!");
		}
	}
	
	function but1(){
		
			document.getElementById('but1').style.backgroundColor='#ff8800'
			document.getElementById('but2').style.backgroundColor='#ff880080'
			document.getElementById('but3').style.backgroundColor='#ff880080'
		
	}
	function but2(){
		
			document.getElementById('but2').style.backgroundColor='#ff8800'
			document.getElementById('but1').style.backgroundColor='#ff880080'
			document.getElementById('but3').style.backgroundColor='#ff880080'
		
	}
	function but3(){
		
			document.getElementById('but3').style.backgroundColor='#ff8800'
			document.getElementById('but2').style.backgroundColor='#ff880080'
			document.getElementById('but1').style.backgroundColor='#ff880080'
		
	}
	function server_form1(){
		
	
		var ss1=document.getElementById('s1').value;
		var ss2="";
		var ss3=document.getElementById('s2').value;
		var ss4=document.getElementById('s3').value;
		var ss5=document.getElementById('s4').value;
		var ss6="";
		var ss7=document.getElementById('s5').value;
		
		var b1=document.getElementById('but1');
		var b2=document.getElementById('but2');
		var b3=document.getElementById('but3');

		var r1=document.getElementById('r1');
		var r2=document.getElementById('r2');
		if(r1.checked==true){
			ss2=r1.value;
		}
		if(r2.checked==true){
			ss2=r2.value;
			
		}
		
		if(document.getElementById('r2').backgroundColor=="rgb(255, 136, 0)"){
			
		}
		
		
		
		if(b1.style.backgroundColor=="rgb(255, 136, 0)"){
		ss6=b1.value;
		}
		if(b2.style.backgroundColor=="rgb(255, 136, 0)"){
		ss6=b2.value;
		}
		if(b3.style.backgroundColor=="rgb(255, 136, 0)"){
		ss6=b3.value;
		}
		
		
		   var xml;
		    
		    if (window.XMLHttpRequest)
			{
				// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				// IE6, IE5 浏览器执行代码
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function()
			{
				if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					var access=xmlhttp.responseText
					
					if(access==3){
						window.alert("错误~无法保存记录");
					}
					if(access==1){
						window.alert("请填写完整");
					}
					if(access==2){
						document.getElementById('server2').style.display='block';
						window.alert("成功");
						document.getElementById('我的地址in').style.display='none';
					}
					if(access==4){
						window.alert("验证码错误");
					}
					
				}
			}
			xmlhttp.open("GET","/cphp/index.php?s1="+ss1+"&s2="+ss2+"&s3="+ss3+"&s4="+ss4+"&s5="+ss5+"&s6="+ss6+"&s7="+ss7,true);
			xmlhttp.send();
		document.getElementById('s1').value="";
		document.getElementById('s2').value="";
		document.getElementById('s3').value="";
		document.getElementById('s4').value="";
		document.getElementById('s5').value="";
		document.getElementById('showadderss_datas').src = "显示地址.php";//更新记录
		
	}

	function code(){
		 var xml;
		    
		    if (window.XMLHttpRequest)
			{
				// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				// IE6, IE5 浏览器执行代码
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}
			xmlhttp.onreadystatechange=function()
			{
				if (xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById("code").src=xmlhttp.responseText;
					document.getElementById("r_code").src=xmlhttp.responseText;
						
				}
			}
			xmlhttp.open("GET","code.php",true);
			xmlhttp.send();
			
	}
	function seesion_user(){
		if(document.getElementById('seesion_user').value!=1){
			document.getElementById('button1').style.display='none';
			document.getElementById('button2').style.display='none';
			document.getElementById('user_name_id').style.display='block';
			document.getElementById('退出账号').style.display='block';
		}else{
			
		}
	}
	function showadderss_data(){
		
		var xml;
		   
		   if (window.XMLHttpRequest)
					{
						// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
						xmlhttp=new XMLHttpRequest();
					}
					else
					{
						// IE6, IE5 浏览器执行代码
						xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.onreadystatechange=function()
					{
						if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
							//document.getElementById("显示地址_btu").innerHTML=xmlhttp.responseText;
						
						}
					}
					xmlhttp.open("GET","显示地址.php",true);
					xmlhttp.send();
					
	}
	function register_but(){
		
		var user=document.getElementById('r_username').value;
		var pass=document.getElementById('r_password').value;
		var code_tools=document.getElementById('code_tools').value;
		
		var xml;
		   
		   if (window.XMLHttpRequest)
					{
						// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
						xmlhttp=new XMLHttpRequest();
					}
					else
					{
						// IE6, IE5 浏览器执行代码
						xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.onreadystatechange=function()
					{
						if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
							
							window.alert(xmlhttp.responseText);
							if(xmlhttp.responseText=="验证码错误"||xmlhttp.responseText=="字符长度不合法"){
								
							}else{
								document.getElementById('register').style.display='none';
							}
							
						
						}
					}
					xmlhttp.open("GET","register.php?user="+user+"&pass="+pass+"&code="+code_tools,true);
					xmlhttp.send();
					document.getElementById('r_username').value="";
					document.getElementById('r_password').value="";
					document.getElementById('code_tools').value="";
	}
	function load(){
		seesion_user()
		document.getElementById('home_f').style.color='#ff8800';
		document.getElementById('home_x').style.backgroundColor='#ff8800';
		//if(document.getElementById('显示地址label').innerText=="1:2            2")
	//window.alert(document.getElementById('显示地址label').innerText);
	//document.write(document.getElementById('显示地址label').innerText);
	}
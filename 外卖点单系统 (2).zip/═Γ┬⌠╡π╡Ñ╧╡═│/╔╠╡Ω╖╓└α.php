<!DOCTYPE html>
<html>
	<head>
		
		
		<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
		
		<meta charset="utf-8">
		<title></title>
		<link rel="stylesheet" type="text/css" href="css/图片切换.css" />
		<script type="text/javascript" src="js/图片切换.js"></script>
		<style>
	body{
		background-color: #ffffff;
		margin:0;
		padding:0;
		
	}
	html, body {
	    max-width: 100%;
	
	    overflow-x: hidden;
	
	}
	

	#展示图片模块{
		width: 360px;
		height: 125px;
		background-color: #FFFFFF;

		top: 1.5%;
		border-radius:20% 20% 20% 20%;
	}
	#食品分类模块{
		width: 360px;
		height: 169px;
		background-color: #FFFFFF;
		
		z-index: 90;
		top: 19%;
		border-radius: 100px 200px 200px 100px;
	}
	#食品分类模块 img{
		width: 70px;
		height: 70px;
		border-radius: 200px 200px 200px 200px;
	}
	#商家模块{
		width: 360px;
		height: 100%;
		background-color: #ffffff;
		
		top: 42.7%;
	}
	#aec a{
		font-size: 13px;
		
	}

	
	.sp{
		background-color: #FFFFFF;
		width: 360px;
		height: 70px;
		margin-bottom: 5px;
		position: relative;	
		padding: 12px;
		padding-left: 40px;
		
	}
	.sp p{
		text-indent: 2em;
	}
	.sp span{
		top: 67px;
		left: 3px;
		background-color: #7d7777;
		position: absolute;
		z-index: 10;
		width: 68px;
		opacity: 0.6;
		color: #FFFFFF;
		border-radius: 0px 0px 10px 10px;
		text-indent: 10px;
		font-size: 14px;
		height: 18px;
	}
	#spimg{
	height: 70px;
	width: 70px;
	vertical-align: middle;
	position: absolute;
	margin-top: 0px;
	left: 0px;
	border-radius: 15px 15px 15px 15px ;
	z-index: 1;
	}
	#but1{
		border: solid 1px #4caf50;
				
		/*很关键：将默认的select选择框样式清除*/
		appearance:none;
		-moz-appearance:none;
		-webkit-appearance:none;
		font-size:9px ;
		bottom: 1px;
		width: 49px;
		background-color: #FFFFFF;
		height: 15px;
		color: #4caf50;
		border-radius: 2px 2px 2px 2px ;
		
	}
	#筛选{
		display: none;
		background-color: #FFFFFF;
		height: 120px;
		width: 50px;
		position: absolute;
		top: 61%;
		left: 70%;
		z-index: 30;
		border-radius: 5px 5px 5px 5px;
		
		
	}
	#商家in{
				background-color: #FFFFFF;
				height: 40px;
				width: 414px;
				z-index: 300;
				position: absolute;
				display: block;
				top: 0px;
				left: 0px;
				position: fixed;
				
			}
	#exit{
		position: absolute;
		left: 10px;
		top: 6px;
		width: 35px;
		height: 35px;
	}

	</style>
		
	<script>
	function text_sp(a,type){
		
		var xml;
		   
		   if (window.XMLHttpRequest)
					{
						// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
						xmlhttp=new XMLHttpRequest();
					}
					else
					{
						// IE6, IE5 浏览器执行代码
						xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.onreadystatechange=function()
					{	
						if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
							document.getElementById("text_sp").innerHTML=xmlhttp.responseText;
							
						}
					}
					xmlhttp.open("GET","商店分类in.php?a="+a+"&type="+type,true);
					xmlhttp.send();
					
	}
	
	function open_http(a){
		
		var xml;
		   
		   if (window.XMLHttpRequest)
					{
						// IE7+, Firefox, Chrome, Opera, Safari 浏览器执行代码
						xmlhttp=new XMLHttpRequest();
					}
					else
					{
						// IE6, IE5 浏览器执行代码
						xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
					}
					xmlhttp.onreadystatechange=function()
					{	
						if (xmlhttp.readyState==4 && xmlhttp.status==200)
						{
							//document.getElementById("text_sp").innerHTML=xmlhttp.responseText;
							
						}
					}
					xmlhttp.open("GET",a,true);
					xmlhttp.send();
					
	}
	
			
	function 进入商家(obj,s5){
		
		var url="/商家in.php?id=" + obj+"&jiage="+ s5 +"&name=";
		  top.location=url;
		//window.open(url);
		
	}
	function 休息中(){
		window.alert("店铺已经打烊咯，明天再来吧");
	}
	
	var $_GET = (function(){
	    var url = window.document.location.href.toString();
	    var u = url.split("?");
	    if(typeof(u[1]) == "string"){
	        u = u[1].split("&");
	        var get = {};
	        for(var i in u){
	            var j = u[i].split("=");
	            get[j[0]] = j[1];
	        }
	        return get;
	    } else {
	        return {};
	    }
	})();
	
	var type="";
	function load(){
		type=$_GET['type'];
		
		if(type==1){
			type="粉面美食";
			
		}
		if(type==2){
			type="炸鸡汉堡";
			
		}
		if(type==3){
			type="包子粥店";
			
		}
		if(type==4){
			type="奶茶甜品";
			
		}
		if(type==5){
			type="小炒快餐";
			
		}
		if(type==6){
			type="西式简餐";
			
		}
		
		text_sp(1,type);
		
		
	}	
	function 筛选a(){
		
		if(document.getElementById('筛选').style.display=='block'){
		document.getElementById('筛选').style.display='none';
		document.getElementById('aec_img').src='ico/arrow2.png';
		document.getElementById('筛选a').style.color='#000000';
		
		}
		else{

		document.getElementById('筛选').style.display='block';
		document.getElementById('aec_img').src='ico/arrow.png';
		document.getElementById('筛选a').style.color='#ff8800';
		}
		
	}
	function exit(){
		var url="index.php";
		window.location=url;
		
	}
	</script>
	</head>
	<body leftmargin="0" onload="load()">

		
	<div id="商家in">
		<img id="exit" src="ico/返回.png" onclick="exit()" /><br />
	</div>
		





		<div id="商家模块">
			
			<br />
			<br />
			
			<br />
		<h3>&nbsp;&nbsp;附近商家</h3>
			
				
				
			</div>
			
			<p style="font-size: 11px;">&nbsp;</p>

			
			<div id="text_sp">
			
		
			
			</div>
		
			
			
			
			
			
			
			<br /><br /><br /><br />
			<br /><br /><br /><br />
			<br /><br /><br /><br />
			<br /><br /><br /><br />
			
		</div>		
		

		
		
		
		
	</body>
</html>


<html>
<head>
	<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<title> 外卖点单系统</title>
	<link rel="stylesheet" type="text/css" href="css/index.css" />
	<script type="text/javascript" src="js/index.js"></script>
<style>
	#user_name_id{
		vertical-align:middle;
	}
	#显示地址{
		width: 414px;
		height: 140px;
		position: fixed;
		top: 70%;
		background-color: #FFFFFF;
	}
	.修改{
		
		<?php
		session_start();
		if($_SESSION["收货地址"]==""){
			echo "display: block;";
		}
		 
		?>
	}
	#商品模块{
		width: 414px;
		height: 100%;
		
		top: 9%;
		}
	#dd_栏目{
		background-color: #FFFFFF;
		height: 70px;
		width: 414px;
	}

</style>

</head>
<body onload="load()">
	
	
	<div id="bg">
		&nbsp;&nbsp;<select name="sel" id="sel"> 
		<option value="老校区">老校区</option> 
		<option value="新校区">新校区</option> 
		</select> 
		<div id="select_x" onclick="select_x()">
			&nbsp;&nbsp;<img src="img/select.png" /><input  name="select" type="text" value="" size="30"  id="select" placeholder="输入商家~ 输入商品" />
		

		</div>
		
		<div id="商品模块">
			
			<iframe id="商品模块in" src="商品模块.php"
			            height="670"
			            width="414"
			            frameborder="0"
			            scrolling="0"
						
			    ></iframe>
			
		</div>
	
		
	</div>
	

	
	
	<div id="搜索">
		<br />&nbsp;&nbsp;<img src="ico/返回.png" onclick="搜索img()" /><br /><br />
		<div id="select_x2">
			&nbsp;<input  name="select" type="text" value="" size="30"  id="select2" placeholder="输入商家~ 输入商品" />&nbsp;<img src="img/select.png" />
		
		</div>
	</div>
	
	
	
	<div id="dd">
	
		<div id="dd_栏目">
		<a style="position: absolute;top: 30px;font-size: 15px;left: 35px; color: #404040;" onclick="
		document.getElementById('hr1').style.left='30px';"
		>全部订单</a>
		
		<a style="position: absolute;top: 30px;font-size: 15px;left: 165px; color: #404040;" onclick="
		document.getElementById('hr1').style.left='155px';"
		>待评价</a>
		
		<a style="position: absolute;top: 30px;font-size: 15px;left: 300px; color: #404040;"onclick= "
		document.getElementById('hr1').style.left='280px';"
		>退款</a>
		<hr id="hr1" style="position: absolute;top: 58px;width: 70px;height: 3px; border: none;background-color: #ff8800;left: 30px;"  />
		</div>
		暂无消息	
	</div>
	
	<div id="user">
		
		<div id="我的地址in" style="display: none;">
			<br />
			&nbsp;&nbsp;<img id="dizhifanghui" src="ico/返回.png" onclick="dizhifanghui()" /><br /><label style="font-size: 20px;">
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;
			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;我的地址</label><br />
			<div style="width: 100%; height: 40px; background-color: #FFFFFF;">
				
				<label style="vertical-align:middle;font-size: 16px;">
			&nbsp;&nbsp;&nbsp;联系人&nbsp;&nbsp;&nbsp;&nbsp;</label><input class="s1"  name="s1" type="text" value="" size="30"  id="s1" style="font-size: 16px"
			 placeholder="请填写收货人姓名" /><br /></div>
		
			<div style="width: 100%; height: 40px; background-color: #FFFFFF;">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input  id="r1" name="Fruit" type="radio" value="先生" onclick="r1()" /><label>先生</label>
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<input id="r2" name="Fruit" type="radio" value="女士" onclick="r2()" /><label>女士</label>
			</div>
			
			<div style="width: 100%; height: 40px; background-color: #FFFFFF;"><label style="vertical-align:middle; font-size: 16px;">
			&nbsp;&nbsp;&nbsp;手机号&nbsp;&nbsp;&nbsp;&nbsp;</label><input  name="select2" type="text" value="" size="30"  id="s2" style="font-size: 16px" placeholder="请填写手机号码" /><br /></div>
			
			<div style="width: 100%; height: 40px; background-color: #FFFFFF;"><label style="vertical-align:middle; font-size: 16px;">
			&nbsp;&nbsp;&nbsp;收货地址&nbsp;&nbsp;&nbsp;&nbsp;</label><input  name="select3" type="text" value="" size="30"  id="s3"style="font-size: 16px" placeholder="请填写收货地址" /><br /></div>
			
			<div style="width: 100%; height: 40px; background-color: #FFFFFF;"><label style="vertical-align:middle; font-size: 16px;">
			&nbsp;&nbsp;&nbsp;门牌号&nbsp;&nbsp;&nbsp;&nbsp;</label><input  name="select4" type="text" value="" size="30"  id="s4" style="font-size: 16px" placeholder="例如:18号楼108室" /><br /></div>
			
			<div  style="width: 100%; height: 40px; background-color: #FFFFFF;"><label style="vertical-align:middle; font-size: 16px;">
			&nbsp;&nbsp;&nbsp;标签&nbsp;&nbsp;&nbsp;&nbsp;</label>
			<input onclick="but1()" id="but1" name="家" type="button" value="家" size="30"  id="b1" />
			<input onclick="but2()" id="but2" name="b2" type="button" value="公司/单位" size="30"  id="b1" />
			<input onclick="but3()" id="but3" name="b3" type="button" value="学校" size="30"  id="b1" /></div>
			<div  style="width: 100%; height: 40px; background-color: #FFFFFF;">
			<label style="vertical-align:middle; font-size: 16px;">
			&nbsp;&nbsp;&nbsp;验证码&nbsp;&nbsp;&nbsp;&nbsp;</label>	
			<input  name="select4" type="text" value="" size="30"  id="s5" style="font-size: 16px;width: 150px;" placeholder="请输入验证码" onclick="code()" />
			<img id="code" src="<?php require_once('code.php');?>" onclick="code()" />
			</div>
			<br />
			<input  style="width: 350px;position: fixed;top: 62%; height: 35px; border: none; background-color: #ff8800; color: #FFFFFF;border-radius: 13px 13px 13px 13px; " 
			type="button" name="server" id="server" value="添加" onclick="server_form1()" />
			&nbsp;&nbsp;<br />
			

			
			
			<div id="显示地址">
				<iframe id="showadderss_datas" src="显示地址.php"
				            height="140"
				            width="414"
				            frameborder="0"
				            scrolling="0"
				    ></iframe>
			
			</div>
		</div>
		<div id="消息in" style="display: none;">
			<br />
			&nbsp;&nbsp;<img id="消息in" src="ico/返回.png" onclick="消息in()" /><br /><br />
			&nbsp;
			<label>消息</label><br /><br />
			<label>暂无消息通知，敬请期待</label>
		</div>
		<div id="优惠卷in" style="display: none;">
			<br />
			&nbsp;&nbsp;<img id="优惠卷in" src="ico/返回.png" onclick="优惠卷in()" /><br /><br />
			&nbsp;
			<label>优惠卷</label><br /><br />
			<label>暂无优惠信息</label>
		</div>
		<div id="关于我们in" style="display: none;">
			<br />
			&nbsp;&nbsp;<img id="关于我们in" src="ico/返回.png" onclick="关于我们in()" /><br /><br />
			&nbsp;&nbsp;<label>关于我们</label>
			<div id="开发者信息">
				<center>
				<img src="img/admin.JPG" /><br />
				<p>一只向梦想远航的狼</p>
				<p>Email:2827262421@qq.com</p>
				</center>
			</div>
		</div>
		<div id="声明和规则in" style="display: none;">
			<br />
			&nbsp;&nbsp;<img id="声明和规则in" src="ico/返回.png" onclick="声明和规则in()" /><br /><br />
			&nbsp;&nbsp;<label>声明与规则</label>
			<div id="信息">
				<iframe src="声明与规则.php"
				            height="700"
				            width="1200"
				            frameborder="0"
				            scrolling="0"
				    ></iframe>
			<label>
			</div>
			</div>
		
		
		
		
		<div id="用户信息"><img src="img/tito.jpg"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<label id="user_name_id" style="display: none;">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<?php session_start(); echo $_SESSION["username"]."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		账户余额:".$_SESSION["qb"]
		
		
		;?></label>
		<input type="button" id="button1" value="登陆" onclick="document.getElementById('login').style.display='block';"/>
		<input type="button" id="button2" value="注册" onclick="document.getElementById('register').style.display='block'" />
		
		<input type="hidden" id="seesion_user" value="1<?php session_start(); echo $_SESSION["username"];?>" />
		</div>
		<br />
		<div id="我的地址" onclick="我的地址()">&nbsp;&nbsp;&nbsp;我的地址<div id="r"><img id="我的地址" src="ico/r.png"/></div></div>
		
		<div id="消息" onclick="消息()">&nbsp;&nbsp;&nbsp;消息<div id="r"><img id="消息" src="ico/r.png"/></div></div>

		<div id="优惠卷" onclick="优惠卷()">&nbsp;&nbsp;&nbsp;优惠卷<div id="r"><img id="优惠卷" src="ico/r.png"/></div></div>

		<div id="关于我们"  onclick="关于我们()">&nbsp;&nbsp;&nbsp;关于我们<div id="r"><img id="关于我们" src="ico/r.png"/></div></div>

		<div id="声明和规则"  onclick="声明和规则()">&nbsp;&nbsp;&nbsp;声明和规则<div id="r"><img id="声明和规则" src="ico/r.png"/></div></div>
		<br /><br /><br /><br />
		
		<div id="退出账号">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		<a href="cphp/free_username.php" style="font-size: 17px; color: #FFFFFF;bottom: none;text-decoration:none; position: fixed;
		top: 80.7%;
		">退出账号</a></div>
	</div>
	
	<div id="底部主体" >
		<div id="home_x"><div><img id="home_ico" src="./ico/home.png" onclick="homeico()" /><br><p style="font-size:16px;" id="home_f">&nbsp;首页</p></div></div>
		<div id="dd_x"><div><img id="dd_ico" src="./ico/dd.png" onclick="ddico()" /><br><p style="font-size:16px;" id="dd_f">&nbsp;订单</p></div></div>
		<div id="user_ico_x"><div><img id="user_ico" src="./ico/user.png" onclick="userico()" /><br><p style="font-size:16px;" id="user_f">&nbsp;我的</p></div></div>
	</div>
	
	<div id="login" style="display: none;">
		<center><br /><br />
		<h3 >登陆<h3><br /><br /></center>
		  <form id="form2" name="form2" method="POST" action="login.php">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input  name="user" type="text" value="" size="30"  id="username" style="font-size: 16px" placeholder="请输入账号" /><br /><br />
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input  name="pass" type="password" value="" size="30"  id="password" style="font-size: 16px" placeholder="请输入密码" /><br />
		
		<br /><br /><br /><br /><center>
		<input type="submit" id="login_but" value="登陆" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		<input type="button" id="login_but2" value="取消" onclick="document.getElementById('login').style.display='none';" /></center>
		</form>
		
	</div>
	
    <div id="register" style="display: none;">
		<center><br /><br />
		<h3 >注册<h3><br /><br /></center>
		 
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input  name="r_user" type="text" value="" size="30"  id="r_username" style="font-size: 16px" placeholder="请输入账号~手机号或邮箱" /><br /><br />
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input  name="r_pass" type="password" value="" size="30"  id="r_password" style="font-size: 16px" placeholder="请输入密码" /><br /><br />
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		
		<div style="width: 318px; height: 37px; background-color: #FFFFFF; position: fixed;left: 8%;top: 286px;border-radius: 14px 14px 14px 14px ;">	
		<input  name="code_tools" type="text" value="" size="30"  id="code_tools" style="font-size: 16px" placeholder="验证码" onclick="code()"  />
			 <img id="r_code" src="<?php session_start(); echo $_SESSION["code_dir"];?>" onclick="code()" />
		</div>
		<br />
		<br /><br /><br /><center>
		<input type="button" id="register_but" value="注册" onclick="register_but()"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		<input type="button" id="register_but2" value="取消" onclick="document.getElementById('register').style.display='none';" />
		</center>
		
		
	</div>
	
	
</body>	
	
</html>

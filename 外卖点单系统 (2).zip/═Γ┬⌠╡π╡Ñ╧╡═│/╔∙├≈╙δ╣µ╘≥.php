<?php require_once('Connections/wm.com.php');?>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
	</head>
	<body>
		<div style="width: 367px; height: auto;">
			<center>
			<h3>总则</h3>
			</center>
			<p>
				<?php
				if ($conn->connect_error) {
					die("连接失败: " . $conn->connect_error);
				} 
				
				$sql2="SELECT * FROM 声明 where id =1";
				$result = $conn->query($sql2);
				
				if ($result->num_rows > 0) {
				    // 输出数据
				    while($row = $result->fetch_assoc()) {
						echo $row["声明与规则"]."<br /><br /><br /><br /><br /><br /><br /><br /><br />";
						
						}
						
				}
				?>
			</p>
			
		</div>
	</body>
</html>
